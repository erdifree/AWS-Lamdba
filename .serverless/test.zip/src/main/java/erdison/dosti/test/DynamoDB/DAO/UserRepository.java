package erdison.dosti.test.DynamoDB.DAO;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

import erdison.dosti.test.Dto.ResponseDto;
import erdison.dosti.test.Dto.UserDto;
import erdison.dosti.test.DynamoDB.Entity.User;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {


    private final DynamoDBMapper dynamoDBMapper;

    public UserRepository(DynamoDBMapper dynamoDBMapper) {
        this.dynamoDBMapper = dynamoDBMapper;
    }

    public ResponseDto save(UserDto user) {
        dynamoDBMapper.save(user);
        return new ResponseDto(200, "User created successfully");
    }

    public User findById(String userId) {
        return dynamoDBMapper.load(User.class, userId);
    }
}

