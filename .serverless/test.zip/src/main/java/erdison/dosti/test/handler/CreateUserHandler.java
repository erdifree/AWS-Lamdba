package erdison.dosti.test.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import erdison.dosti.test.Dto.ResponseDto;
import erdison.dosti.test.Dto.UserDto;
import erdison.dosti.test.service.UserService;
import org.springframework.stereotype.Component;
import java.util.Base64;

@Component
public class CreateUserHandler implements RequestHandler<String, ResponseDto> {
    private final UserService userService;
    private final ObjectMapper objectMapper;

    public CreateUserHandler(UserService userService, ObjectMapper objectMapper) {
        this.userService = userService;
        this.objectMapper = objectMapper;
    }

    @Override
    public ResponseDto handleRequest(String base64Payload, Context context) {
        // Decodifica il payload Base64 in una stringa JSON
        byte[] decodedBytes = Base64.getDecoder().decode(base64Payload);
        String jsonPayload = new String(decodedBytes);

        try {
            // Converte la stringa JSON in un oggetto UserDto
            UserDto userDto = objectMapper.readValue(jsonPayload, UserDto.class);

            // Ora puoi utilizzare userDto per creare l'utente
            return userService.createUser(userDto);
        } catch (Exception e) {
            // Gestisci l'eccezione in caso di errore nella conversione JSON
            e.printStackTrace();
            return new ResponseDto(500, "Error processing request");
        }
    }
}
