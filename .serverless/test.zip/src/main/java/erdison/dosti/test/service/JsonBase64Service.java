package erdison.dosti.test.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class JsonBase64Service {

    private final ObjectMapper objectMapper;

    public JsonBase64Service(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String convertObjectToJsonAndEncodeBase64(Object object) {
        try {
            // Converti l'oggetto in una stringa JSON
            String json = objectMapper.writeValueAsString(object);

            // Codifica la stringa JSON in Base64
            byte[] base64Bytes = Base64.getEncoder().encode(json.getBytes());
            return new String(base64Bytes);
        } catch (JsonProcessingException e) {
            // Gestisci l'eccezione se si verifica un errore di conversione
            e.printStackTrace();
            return null;
        }
    }
}
