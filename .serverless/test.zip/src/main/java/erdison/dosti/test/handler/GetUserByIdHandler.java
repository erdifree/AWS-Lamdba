package erdison.dosti.test.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import erdison.dosti.test.Dto.UserDto;
import erdison.dosti.test.service.UserService;
import org.springframework.stereotype.Component;


@Component
public class GetUserByIdHandler implements RequestHandler<String, UserDto> {

   private final UserService userService;

    public GetUserByIdHandler(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDto handleRequest(String userId, Context context) {
        return userService.getUserById(userId);
    }
}
